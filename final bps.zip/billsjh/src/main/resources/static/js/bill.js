var gData;

$(document).ready(function() {

	$(".query-form").hide();
	// $(".image-form").hide();

	// $(".payment-form").hide();
});
// function details() {
//
// }



function logout() {
	sessionStorage.clear();
	window.location = "index.html";
}

function init() {
	if (sessionStorage.getItem("auth") != "yes") {

		window.location = 'index.html';

	}

}
/*
 * function Details() {
 * 
 * $(".guide-line").hide();
 * 
 * $(".query-form").hide();
 * 
 * $(".image-form").show();
 * 
 * $(".payment-form").show(); }
 */

function details() {

	$("#vendorType").empty();

	var str1 = $("#CustomerId").val();
	if(str1==""){
		alert("customer Id can't be null boy");
		window.location="billupdate.html";
	}
	var url = "http://localhost:3100/customers/" + str1;

	$.ajax({
		type : "GET",
		url : url,
		dataType : "json",
		async : false,
		success : function(data) {

			$(".customer-search").hide();

			$(".query-form").show();

			gData = data;
			console.log(data);
			var opt = '<option value="0" selected disabled>Select</option>';
			$("#vendorType").append(opt);
			for (i = 0; i < data.vendorType.length; i++) {
				var opt = '<option value="' + data.vendorType[i].vendorType
						+ '">' + data.vendorType[i].vendorType + '</option>';
				$("#vendorType").append(opt);
			}
		},
		error : function() {
			alert("Customer Id not valid");
			$("#CustomerId").val(null);
		}
	});
}


function getCardValidity() {

	var c1 = gData.cardValidity;
	var c2 = $("#customerCardValidity").val();
	if (c1 != c2) {
//		$("#customerCardValidity").val("");
		alert("cardValidity invalid Sir");
	}
}

function checkCard() {

	var c1 = gData.cardNumber;
	var c2 = $("#customerCardNumber").val();
	if (c1 != c2) {
		$("#customerCardNumber").val(null);
		alert("cardNumber invalid Sir");
	}
}

function checkCVV() {

	var c1 = gData.cvv;
	var c2 = $("#cvv").val();
	if (c1 != c2) {
		$("#cvv").val(null);
		alert("cvv invalid Sir");
	}

}

function checkCardType() {

	var c1 = gData.cardType;
	var c2 = $("#customerCardType").val();
	if (c1 != c2) {
		$("#customerCardType").val(null);
		alert("cardtype invalid Sir");
	}
}

function saveBill() {

	var billData = getJsonBill();
	var billContollerUrl = "http://localhost:3100/billDetails/savebill";
	$.ajax({
		type : "POST",
		url : billContollerUrl,
		data : billData,
		async : false,
		contentType : "application/json",
		dataType : "json",
		success : function(response) {

			alert("Payment done Successfully Sir");
			window.location = "/dashboard.html";

		},

		error : function() {
			alert('gg');
		}

	});

}


function getJsonBill() {
	var $items = $('#vendorType, #vendorName, #amountPaid');

	var obj = {};
	obj.customerId = gData.customerId;
	$items.each(function() {
		obj[this.id] = $(this).val();
	});
	var json = JSON.stringify(obj);
	return json;
}

function populateNames() {

	$("#vendorName").empty();

	var str1 = $("#vendorType").val();
	var url = "http://localhost:3100/Vendors/" + str1 + "/names";

	$.ajax({
		type : "GET",
		url : url,
		dataType : "json",
		async : false,
		success : function(data) {
			var opt = '<option value="0" disabled>Select</option>';
			$("#vendorName").append(opt);
			for (i = 0; i < data.length; i++) {

				var opt = '<option value="' + data[i] + '">' + data[i]
						+ '</option>';
				$("#vendorName").append(opt);
			}
		},
		error : function() {
			alert("Vendor Type Could Not Be Fetched");
		}
	});

	getAmount();
}

function getAmount() {

	for (i = 0; i < gData.vendorType.length; i++) {
		if (gData.vendorType[i].vendorType == $('#vendorType').val()) {
			$('#amount').empty();
			$('#amount').val(gData.vendorType[i].amount);
		}
	}
}

jQuery(function($) {
	/*$.validator.addMethod("vendort", function(value) {
		if (value == "0") {
			return false;
		} else {
			return true;
		}
	});
	$.validator.addMethod("vendorn", function(value) {
		if (value == "0") {
			return false;
		} else {
			return true;
		}
	});*/

	$("#details-form").validate({

		rules : {

//			vendorType : {
//
//				vendort : true
//			},
//
//			vendorName : {
//				vendorn : true
//			},

		},
		messages : {

//			vendorType : {
//
//				vendort : "Select the vendorType"
//			},
//			vendorName : {
//				vendorn : "Select the vendorName"
//			},

		},

	// submitHandler : function() {

	// $(".customer-search").hide();

	// $(".query-form").show();

	// // $(".guide-line").hide();

	// // $(".query-form").hide();

	// // $(".image-form").show();

	// // $(".payment-form").show();

	// }

	}),

	$("#contact-form").validate({

		rules : {
			cardNum : {
				required : true,
				digits : true,
				minlength : 16,
				maxlength : 16

			},

			cvv : {
				required : true,
				digits : true,
				minlength : 3,
				maxlength : 3
			},
			validityMonth : {
				required : true
			},
		},
		messages : {
			cardNum : {
				required : "Please enter your number",
				digits : "Please enter valid number",
				minlength : "Please enter 16 digits",
				maxlength : "Only 16 digits allowed"
			},

			cvv : {
				required : "Please enter your number",
				digits : "Please enter valid number",
				minlength : "Please enter 3 digits",
				maxlength : "Only 3 digits allowed"

			},
			validityMonth : {
				required : "Please enter the validity month and year"
			},
		},
		submitHandler : function(form) {
			form.submit();
		}
	});
	
//	$("#search-form").validate({
//
//		rules : {
//			customerId : {
//				required : true,
//				digits : true
//			},
//		},
//		messages : {
//			customerId : {
//				required : "Please enter your Customer Id",
//				digits : "Please enter only digits"
//			},
//		},
//		submitHandler : function(form) {
//			form.submit();
//		}
//	});

});
