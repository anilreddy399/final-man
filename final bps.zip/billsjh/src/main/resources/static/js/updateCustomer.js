/*$(".customer-form").hide();*/
$(document).ready(function() {
	$(".customer-form").hide();
	$(".customer-details").hide();

	/* $(".payment-form").hide(); */
});

var gData;

function showUpdate() {

	var cid = $("#customerIdQuery").val();
	$('#customerId').empty();
	$('#customerId').append(cid);
	if (cid == "") {
		alert("Please enter the Id");
		window.location = "updateCustomer.html";
	}
   
	else{
	var searchContollerUrl = "http://localhost:3100/customers/" + cid;
	$.ajax({
		type : "GET",
		url : searchContollerUrl,
		dataType : "json",
		async : false,
		success : function(response) {

			$("#cSearch").hide();
			$(".customer-form").show();
			$(".customer-details").show();
			$("#customerId").show();

			// $("#uName").val(response.customerName);
			gData = response;
			console.log(response);

			$("#customerName").val(response.customerName);
			$("#customerAddress").val(response.customerAddress);
			$("#customerContactNumber").val(response.customerContactNumber);
			$("#customerMailId").val(response.customerMailId);
			$("#customerCountry").val(response.customerCountry);
			$("#customerState").val(response.customerState);
			$("#customerIdentificationdocument").val(
					response.customerIdentificationdocument);
			$("#customerDocumentDetailNumber").val(
					response.customerDocumentDetailNumber);
			$("#customerRegistrationDate").val(
					response.customerRegistrationDate.toString().substring(0,10));
			// $("#vendorType").val(response.vendorType);
			$("#customerCardNumber").val(response.cardNumber);
			$("#customerCardType").val(response.cardType);
			$("#customerCardValidity").val(response.cardValidity);
			$("#cvv").val(response.cvv);
			$("#customerBalance").val(response.customerBalance);

			for (i = 0; i < response.vendorType.length; i++) {
				if (response.vendorType[i].vendorType == "Electricity") {
					$('#electricityType').prop('checked', true);
				}
				if (response.vendorType[i].vendorType == "Telephone") {
					$('#telephoneType').prop('checked', true);
				}
				if (response.vendorType[i].vendorType == "Insurance") {
					$('#insuranceType').prop('checked', true);
				}
				if (response.vendorType[i].vendorType == "Tax") {
					$('#taxType').prop('checked', true);
				}
			}

		},

		error : function() {
			alert('error');
		}
	});
}
}

function updateCustomer() {
	var loginData = getJson();
	var customerContollerUrl = "http://localhost:3100/customers/update";
	$.ajax({
		type : "POST",
		async : false,
		url : customerContollerUrl,
		data : loginData,
		contentType : "application/json",
		dataType : "json",
		success : function(response) {

			console.log(response);
			$("#modal").on("hidden.bs.modal", function() {
				window.location = "/dashboard.html";
			});
			$("#modal").modal('show');
			// alert("Customer updated successfully")
			// window.location = "/dashboard.html";
		},

		error : function() {
			alert("error")
		}

	});
}
function getFalse() {
	return false;
}
function getJson() {
	var $items = $('#customerName,#customerCardType,#cvv,#customerCardValidity,  #customerAddress, #customerContactNumber, #customerMailId, #customerCountry, #customerState, #customerIdentity, #customerIdentificationdocument,  #customerDocumentDetailNumber,#customerRegistrationDate, #vendorType, #customerCardNumber, #customerBalance');
	var vTyp = [];
	if ($('#electricityType').prop('checked')) {
		vTyp.push("Electricity");
	}
	if ($('#taxType').prop('checked')) {
		vTyp.push("Tax");
	}
	if ($('#insuranceType').prop('checked')) {
		vTyp.push("Insurance");
	}
	if ($('#telephoneType').prop('checked')) {
		vTyp.push("Telephone");
	}
	var obj = {};
	obj.vendorType = vTyp;
	obj.customerId = $("#customerIdQuery").val();
	$items.each(function() {
		obj[this.id] = $(this).val();
	});
	var json = JSON.stringify(obj);

	return json;
}

function logout() {
	sessionStorage.clear();
	window.location = "index.html";
}

function init() {
	if (sessionStorage.getItem("auth") != "yes") {
		alert("please login first.");
		window.location = 'index.html';
	}

}
/*
 * function updateCustomer() { var loginData = getJson(); var
 * customerContollerUrl = "http://localhost:3100/customers/update"; $.ajax({
 * type : "POST", async : false, url : customerContollerUrl, data : loginData,
 * contentType : "application/json", dataType : "json", success :
 * function(response) {
 * 
 * console.log(response);
 * 
 * alert('Customer updated Successfully');
 *  },
 * 
 * error : function() { alert('Customer Update Failed'); }
 * 
 * });
 */

jQuery(function($) {

	var dropvar;

	// for name validation

	$.validator.addMethod("alpha", function(value, element) {

		return this.optional(element) || value == value.match(/^[a-zA-Z\s]+$/)
				&& value != value.match(/[\s]+/);

	});

	$.validator.addMethod("text", function(value, element) {

		return this.optional(element) || value != value.match(/[\s]+/);

	});

	$.validator.addMethod("countrydd", function(value) {

		if (value == "0") {

			return false;

		}

		else {

			return true;

		}

	});

	$.validator.addMethod("statedd", function(value) {

		if (value == "0") {

			return false;

		}

		else {

			return true;

		}

	});

	$.validator.addMethod("identity", function(value) {

		// if (value == "0") {

		// return false;

		// }

		if (dropvar == "GMV") {

			return (value != value.match(/[\s]+/) && value == value
					.match(/^GMV[a-zA-Z0-9]+$/));

		}

		else if (dropvar == "PASS") {

			return (value != value.match(/[\s]+/) && value == value
					.match(/^PASS[a-zA-Z0-9]+$/));

		}

		else if (dropvar == "DL") {

			return (value != value.match(/[\s]+/) && value == value
					.match(/^DL[a-zA-Z0-9]+$/));

		}

		else if (dropvar == "PAN") {

			return (value != value.match(/[\s]+/) && value == value
					.match(/^PAN[a-zA-Z0-9]+$/));

		}

	});

	$.validator.addMethod("dropdown", function(value) {

		dropvar = value;

		if (dropvar == "0") {

			return false;

		}

		else {

			return true;

		}

	});

	$.validator.addMethod("vendordd", function(value) {

		if (value == "0") {

			return false;

		}

		else {

			return true;

		}

	});

	$("#customer-form").validate({

		rules : {

			name : {

				required : true,

				alpha : true,

				text : true

			},

			address : {

				required : true,

				text : true

			},

			email : {

				required : true,

				email : true

			},

			country : {

				required : true

			},

			state : {

				statedd : true

			},

			number : {

				required : true,

				digits : true,

				minlength : 10,

				maxlength : 10

			},

			identity : {

				dropdown : true

			},

			docdetailnumber : {

				required : true,

				identity : true

			},

			date : {

				required : true,

				date : true

			},

			vendorType : {

				vendordd : true

			},

			cardNum : {

				required : true,

				digits : true,

				minlength : 16,

				maxlength : 16

			},

			cvv : {

				required : true,

				digits : true,

				minlength : 3,

				maxlength : 3

			},

			validityMonth : {

				required : true

			},

			balance : {

				required : true,

				digits : true

			},

		},

		messages : {

			name : {

				required : "Please enter your name",

				alpha : "Alphabets and spaces only allowed",

				text : "Please enter a valid name"

			},

			address : {

				required : "Please enter your address",

				text : "Please enter valid address"

			},

			email : {

				required : "Please enter an email address",

				email : "Please enter a valid email address"

			},

			country : {

				countrydd : "Please select one option"

			},

			state : {

				statedd : "Please select one option"

			},

			number : {

				required : "Please enter your number",

				digits : "Please enter valid number",

				minlength : "Please enter minimum 10 digits",

				maxlength : "Only 10 digits allowed"

			},

			identity : {

				dropdown : "Please select one option"

			},

			docdetailnumber : {

				required : "Please enter your ID",

				identity : "Please enter Valid ID"

			},

			date : {

				required : "Please select a date"

			},

			vendorType : {

				vendordd : "Please select one option"

			},

			cardNum : {

				required : "Please enter card number",

				digits : "Only numbers allowed",

				minlength : "Please enter 16 digits",

				maxlength : "Only 16 digits allowed"

			},

			cvv : {

				required : "Please enter your number",

				digits : "Please enter valid number",

				minlength : "Please enter 3 digits",

				maxlength : "Only 3 digits allowed"

			},

			validityMonth : {

				required : "Please enter the validity month and year"

			},

			balance : {

				required : "Please enter balance",

				digits : "Only numbers allowed"

			},

		},

		submitHandler : function(form) {

			form.submit();

		}

	});

});

// }
